---
name: rg-mobile-auto-build
description: "创建模块、生成React模块目录结构、自动生成页面组件和model文件。支持指令格式：创建模块 XX，页面叫 XX，类型是列表页面；创建模块 XX，页面叫 XX，类型是基础页面；根据skills创建模块 XX，页面叫 XX，类型是列表页面等。专门处理React模块创建任务，支持基础页面和列表页面模板。"
---

# React 模块自动生成工具

## 功能说明

本技能用于自动生成 React 模块的完整目录结构，包括页面组件、model、service、路由配置等文件。支持基础页面和列表页面两种模板。

## 使用方法

请按照以下格式描述您需要创建的模块：

```
用rg-mobile-auto-build skill创建模块 <模块名称>，页面叫 <页面名称>，类型是 <页面类型>
```

其中：
- `<模块名称>`：模块的标识名称（如：activity）
- `<页面名称>`：页面的标识名称（如：discover）
- `<页面类型>`：页面类型，可选值：`基础页面` 或 `列表页面`

## 示例指令

1. `创建模块 activity，页面叫 discover，类型是基础页面`
2. `创建模块 user，页面叫 profile，类型是列表页面`
3. `创建模块 order，页面叫 list，类型是列表页面`

## 生成的文件结构

### 模块目录结构

```
<模块名称>/
  ├── pages/
  │   ├── <页面名称>.tsx          # 页面组件
  │   └── index.tsx               # 路由导出文件
  └── models/
  │   ├── <页面名称>.tsx          # 页面组件
  │   └── index.tsx               # 路由导出文件
  └──  services/
      ├── <页面名称>.service.ts    # 页面 service，创建空页面即可
      └── index.ts                # service 导出，创建空页面即可
```

## 文件内容模板

### 1. models/common.ts（命名空间定义）

```typescript
export enum Namespaces {
    <模块名称> = "ipark-<模块名称>"
}
```

### 2. models/<页面名称>.model.ts（页面 model）

```typescript
import { EffectsMapObject } from "dva";

import { ReducersMapObject, AnyAction } from "redux";

import { freeze } from "immer";

import { CoreEffects, CoreReducers } from "@reco-m/core";

import { app } from "@reco-m/core-ui";

import { Namespaces } from "./common";

export namespace <页面名称>Model {

    export const namespace = Namespaces.<模块名称>;

    export type StateType = typeof state;

    export const state: any = freeze(
        {
        },
        !0
    );

    export const reducers: ReducersMapObject<any, AnyAction> = {
        ...CoreReducers,

        init() {
            return state;
        },
    };

    export const effects: EffectsMapObject = {
        ...CoreEffects,
        *initPage({ data, message }, { put }) {
            put({ type: "showLoading" });
            try {
                yield put({ type: "getDatas", data, message });
            } catch (e) {
                console.log('catcherror', e?.errmsg||e);
                message!.error(`${e?.errmsg || e}`);
            }
        },
        *getDatas({ message }, { put }) {
            try {
                console.log("getDatas");
            } catch (e) {
                console.log('catcherror', e?.errmsg||e);
                message!.error(`${e?.errmsg || e}`);
            } finally {
                yield put({ type: "hideLoading" });
            }
        }
    };
}

app.model(<页面名称>Model);
```
如果开发中提供了具体业务的接口要创建列表页面，更多列表页面搭建细节可以参考[列表搭建细节](references/mobilelistbuild.md),如果检索不到该文件就使用技能rg-mobile-list-build来创建，其中包含了列表页面的状态管理、分页数据更新、竞态控制等关键逻辑（注意：创建列表需要严格按照模板规范，避免手动修改模板代码，特别是 getXxxPage 方法，它是列表数据更新的核心逻辑）。

### 3. models/index.ts（model 导出）

```typescript
export * from "./common";
export * from "./<页面名称>.model";
```

### 4. pages/<页面名称>.tsx（基础页面模板）

```typescript
import React from "react";

import { template } from "@reco-m/core";

import { ViewComponent } from "@reco-m/core-ui";

import { Namespaces, <页面名称>Model } from "../models";

export namespace <页面名称> {
    export interface IProps<S extends IState = IState> extends ViewComponent.IProps<S> {
        selectTagtest?: any;
    }
    export interface IState extends ViewComponent.IState, <页面名称>Model.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ViewComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.<模块名称>;
        headerContent = "";

        componentDidMount() {}

        renderBody(): React.ReactNode {
            const { state } = this.props;
            return <div></div>;
        }
    }

    export const Page = template(Component, (state) => state[Namespaces.<模块名称>]);
}
```

### 5. pages/<页面名称>.tsx（列表页面模板）

```typescript
import React from "react";

import { template } from "@reco-m/core";

import { ListComponent, Container } from "@reco-m/core-ui";

import { Namespaces, <页面名称>Model } from "../models";

export namespace <页面名称> {
    export interface IProps<S extends IState = IState> extends ListComponent.IProps<S> {
        selectTagtest?: any;
    }
    export interface IState extends ListComponent.IState, <页面名称>Model.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ListComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.<模块名称>;
        headerContent = "";

        componentDidMount() {}
        /**
         * 刷新列表
         */
        onRefresh() {}

        /**
         * 上拉刷新
         */
        pullToRefresh() {
            this.getData(1);
        }

        /**
         * 渲染列表项内容
         */
        renderItemContent() {
            return <></>
        }

        /**
         * 下拉刷新
         */
        onEndReached() {
            const { state } = this.props;
            this.getData((state!.pageIndex || 0) + 1);
        }
        getData(pageIndex?: number) {}
        renderBody(): React.ReactNode {
            const { state } = this.props;
            return (state as any).refreshing !== false ? null : <Container.Component body>{this.getListView()}</Container.Component>;
        }
    }

    export const Page = template(Component, (state) => state[Namespaces.<模块名称>]);
}
```
如果开发中提供了具体业务的接口要创建列表页面，更多列表页面搭建细节可以参考[列表搭建细节](references/mobilelistbuild.md),如果检索不到该文件就使用技能rg-mobile-list-build来创建，其中包含了列表页面的状态管理、分页数据更新、竞态控制等关键逻辑（注意：创建列表需要严格按照模板规范，避免手动修改模板代码，特别是 getXxxPage 方法，它是列表数据更新的核心逻辑）。

### 6. pages/index.tsx（路由导出文件）

```typescript
import { Route } from "@reco-m/core-ui";

import { router } from "dva";

import { <页面名称> } from './<页面名称>'

export { <页面名称> };

export function <模块名称>Routes(match: router.match) {
  return (
      <Route
          path={`${match.path}/${<模块名称>}`}
          render={({ match }) => (
              <>
                  <Route path={match.path} component={<页面名称>.Page} />
                  {/* <模块名称>DetailRoutes(match) */}
              </>
          )}
      />
  );
}
```

## 页面类型说明

### 基础页面

适用于普通展示页面，包含：
- ViewComponent 基础组件
- 生命周期方法 componentDidMount
- renderBody 方法用于渲染页面内容

### 列表页面

适用于列表展示页面，包含：
- ListComponent 列表组件
- 上拉刷新功能 (pullToRefresh)
- 下拉加载更多 (onEndReached)
- 渲染列表项内容 (renderItemContent)
- 数据获取方法 (getData)
- 刷新列表方法 (onRefresh)

## 替换说明

在生成文件时，请将以下占位符替换为实际值：

- `<模块名称>`：替换为模块的标识名称（如：activity）
- `<页面名称>`：替换为页面的标识名称（如：discover）

## 示例生成结果

### 示例：创建模块 activity，页面叫 discover，类型是基础页面

#### 1. activity/models/common.ts

```typescript
export enum Namespaces {
    activity = "ipark-activity"
}
```

#### 2. activity/models/discover.model.ts

```typescript
import { EffectsMapObject } from "dva";

import { ReducersMapObject, AnyAction } from "redux";

import { freeze } from "immer";

import { CoreEffects, CoreReducers } from "@reco-m/core";

import { app } from "@reco-m/core-ui";

import { Namespaces } from "./common";

export namespace discoverModel {

    export const namespace = Namespaces.activity;

    export type StateType = typeof state;

    export const state: any = freeze(
        {
        },
        !0
    );

    export const reducers: ReducersMapObject<any, AnyAction> = {
        ...CoreReducers,

        init() {
            return state;
        },
    };

    export const effects: EffectsMapObject = {
        ...CoreEffects,
        *initPage({ data, message }, { put }) {
            put({ type: "showLoading" });
            try {
                yield put({ type: "getDatas", data, message });
            } catch (e) {
                console.log('catcherror', e?.errmsg||e);
                message!.error(`${e?.errmsg || e}`);
            }
        },
        *getDatas({ message }, { put }) {
            try {
                console.log("getDatas");
            } catch (e) {
                console.log('catcherror', e?.errmsg||e);
                message!.error(`${e?.errmsg || e}`);
            } finally {
                yield put({ type: "hideLoading" });
            }
        }
    };
}

app.model(discoverModel);
```

#### 3. activity/models/index.ts

```typescript
export * from "./common";
export * from "./discover.model";
```

#### 4. activity/pages/discover.tsx

```typescript
import React from "react";

import { template } from "@reco-m/core";

import { ViewComponent } from "@reco-m/core-ui";

import { Namespaces, discoverModel } from "../models";

export namespace discover {
    export interface IProps<S extends IState = IState> extends ViewComponent.IProps<S> {
        selectTagtest?: any;
    }
    export interface IState extends ViewComponent.IState, discoverModel.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ViewComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.activity;
        headerContent = "";

        componentDidMount() {}

        renderBody(): React.ReactNode {
            const { state } = this.props;
            return <div></div>;
        }
    }

    export const Page = template(Component, (state) => state[Namespaces.activity]);
}
```

#### 5. activity/pages/index.tsx

```typescript
import { Route } from "@reco-m/core-ui";

import { router } from "dva";

import { discover } from './discover'

export { discover };

export function activityRoutes(match: router.match) {
  return (
      <Route
          path={`${match.path}/activity`}
          render={({ match }) => (
              <>
                  <Route path={match.path} component={discover.Page} />
                  {/* activityDetailRoutes(match) */}
              </>
          )}
      />
  );
}
```

## 注意事项

1. 请确保模块名称和页面名称使用小写字母，避免使用特殊字符
2. 如果模块已存在，只需要在对应目录创建页面和对应 model 即可
3. 路由配置中需要根据实际情况添加详情页面路由
4. 可以根据项目需求调整页面模板中的代码逻辑

## 自定义扩展

您可以根据项目需求对模板进行以下扩展：

1. 在页面组件中添加更多生命周期方法
2. 扩展 model 中的状态和效果
3. 添加更多路由配置
4. 集成项目特定的组件和工具

通过参考本技能提供的模板，您可以快速创建标准化的 React 模块结构。