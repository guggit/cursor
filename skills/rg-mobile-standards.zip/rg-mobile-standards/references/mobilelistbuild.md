下面以资讯为例
如后端提供接口https://fat.bitechdevelop.com/reco-biparkall-10-5-mobileapi/article/article/?pageSize=1

公司列表接口返回通用格式如
   ```json
   {
       "currentPage": 1,
       "totalPages": 1,
       "totalItems": "19",
       "itemsPerPage": 25,
       "items": []
   }
   ```
可以此创建基本列表页面如下

### 页面模版
```typescript
import React from "react";
import { template } from "@reco-m/core";
import { ListComponent, Container } from "@reco-m/core-ui";
import { Namespaces, xxxModel } from "../models";

export namespace Xxx {
    export interface IProps<S extends IState = IState> extends ListComponent.IProps<S> {}
    export interface IState extends ListComponent.IState, xxxModel.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ListComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.xxx;
        headerContent = "列表标题";
        componentDidMount() { this.dispatch({ type: "initPage", data: {} }); }
        componentWillUnmount() { this.dispatch({ type: "init" }); }
        /** 刷新列表 */
        onRefresh() { this.getData(1); }
        /** 下拉刷新 */
        pullToRefresh() { this.getData(1); }
        /** 上拉加载更多 */
        onEndReached() { this.getData((this.props.state!.pageIndex || 0) + 1); }
        /** 获取数据 */
        getData(pageIndex?: number) { this.dispatch({ type: "getList", pageIndex }); }
        /** 渲染列表项 */
        renderItemContent(item: any, i: number): React.ReactNode { return <div key={item.id || i}></div>; }
        renderBody(): React.ReactNode {
            const { state } = this.props;
            return (state as any).refreshing !== false ? null : <Container.Component body>{this.getListView()}</Container.Component>;
        }
    }
    export const Page = template(Component, (state) => state[Namespaces.xxx]);
}
```


### **页面Model完整模板**
```typescript
import { EffectsMapObject } from "dva";
import { ReducersMapObject, AnyAction } from "redux";
import produce, { freeze } from "immer";
import { CoreEffects, CoreReducers } from "@reco-m/core";
import { app } from "@reco-m/core-ui";
import { xxxHttpService } from "@reco-m/xxx-service";
import { Namespaces } from "./common";

export namespace xxxModel {
    /** 用于防止过时请求的竞态控制 */
    let changeCounter = 0;

    export const namespace = Namespaces.xxx;
    
    export type StateType = typeof state;
    
    export const state: any = freeze({
    }, !0);

    export const reducers: ReducersMapObject<any, AnyAction> = {
        ...CoreReducers,
        /** 清空状态（返回首页时使用） */
        init() { return state; },
        
        /**
         * 通用列表分页数据更新 reducer
         * @param state 当前状态
         * @param action.payload 包含 { params, thisChangeId } 的 payload
         * params: 接口返回的分页数据
         * thisChangeId: 本次请求的标识，用于防止过时响应
         */
        getXxxPage(state, { params, thisChangeId }) {
            // 竞态控制：如果当前请求 ID 小于最新计数器，说明是过期响应，直接返回
            if (thisChangeId < changeCounter) return state;
            
            return produce(state, (draft) => {
                Object.assign(draft, params, {
                    // 如果是第一页，直接覆盖；否则追加到现有列表
                    items: params.currentPage <= 1 ? params.items : [...draft.items, ...params.items],
                    // 重置下拉刷新状态
                    refreshing: false,
                    // 计算是否还有更多数据
                    hasMore: params.currentPage < params.totalPages
                });
            });
        },
    };

    export const effects: EffectsMapObject = {
        ...CoreEffects,
        
        /**
         * 页面初始化（标准流程）
         * 1. 显示 loading
         * 2. 保存初始搜索参数
         * 3. 获取列表数据
         */
        *initPage({ data, message }, { put }) {
            yield put({ type: "showLoading" });
            try {
                // 获取列表数据
                yield put({ type: "getList", data, message });
            } catch (e) {
                console.error('catcherror', e?.errmsg || e);
                message?.error(`${e?.errmsg || e}`);
            }
        },
        
        /**
         * 获取列表数据（标准流程）
         * 1. 生成请求ID（竞态控制）
         * 2. 调用接口获取分页数据
         * 3. 将结果存入 state
         * 4. 异常处理和 loading 控制
         */
        *getList({ message, data }, { call, put }) {
            try {
                // 竞态控制：每次请求增加计数器
                const thisChangeId = ++changeCounter;
                
                // 调用接口获取分页数据
                const params = yield call(xxxHttpService.getPaged, { 
                    pageSize: 15
                    ...data                    // 合并传入的查询条件
                });
                
                // 将结果存入 state
                yield put({ 
                    type: "getXxxPage", 
                    params: { 
                        ...params, 
                        thisChangeId           // 传递请求ID用于竞态判断
                    } 
                });
            } catch (e) {
                console.error('catcherror', e?.errmsg || e);
                message?.error(`${e?.errmsg || e}`);
            } finally {
                // 无论成功失败，都要隐藏 loading
                yield put({ type: "hideLoading" });
            }
        }
        
    };
}

app.model(xxxModel);
```
model中使用的service（xxxHttpService）模版如下
```typescript
import { HttpService, resolveService } from "@reco-m/core";

export class XxxHttpService extends HttpService {
    constructor() { super("article/article"); }
}
export const xxxHttpService = resolveService(XxxHttpService);
```
---

### **关键逻辑说明**
此模板可直接复用于新页面的列表Model，只需替换命名空间和接口服务名称。（注意：创建列表需要严格按照模板规范，避免手动修改模板代码，特别是 getXxxPage 方法，它是列表数据更新的核心逻辑）