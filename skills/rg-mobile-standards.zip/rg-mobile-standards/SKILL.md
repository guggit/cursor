---
name: rg-mobile-standards
description: "RECO IPark+ 移动端项目规范与代码模式速查。涵盖模块目录结构、页面组件模板（ViewComponent/ListComponent/EfficientFormViewComponent）、dva model、HttpService 接口封装、路由定义、命名空间、枚举命名、样式类名、表单校验、侧边栏筛选、事件通信等。生成代码、新建页面、新建模块、封装接口、编写 model 时自动应用。Use when generating React components, pages, models, services, routes, or any code in RECO IPark+ mobile project."
---

# RECO IPark+ 移动端项目规范速查

生成代码时直接参照本文件中的结构与模式，无需重新扫描项目。

## 1. 技术栈

| 领域 | 方案 |
|------|------|
| 框架 | React 18（类组件为主） |
| 状态管理 | dva（redux-saga） |
| 不可变数据 | immer（`produce` / `freeze`） |
| 路由 | react-router v5 + dva/router |
| UI 组件库 | antd-mobile v5 |
| HTTP 请求 | 自研 `HttpService`（`@reco-m/core`） |
| 组件基类 | `ViewComponent.Base` / `ListComponent.Base`（`@reco-m/core-ui`） |
| 表单基类 | `EfficientFormViewComponent.Component`（`@reco-m/efficient-page`） |
| 模板绑定 | `template()` 连接组件与 dva store |
| 服务注入 | `resolveService()` 单例工厂 |

---

## 2. 模块目录结构

每个业务模块遵循 **三层分离**（视图 / 模型 / 服务）：

```
src/apps/<模块名>/
├── <模块名>/              # 页面组件层（@reco-m/<模块名>）
│   ├── <页面>.tsx         # 页面组件
│   ├── <页面>.detail.tsx  # 详情页面
│   └── index.tsx          # 路由定义 + 组件导出
├── models/                # 模型层（@reco-m/<模块名>-models）
│   ├── common.ts          # Namespaces 枚举 + 公共常量
│   ├── <页面>.model.ts    # 页面 model
│   └── index.ts           # 桶导出 export *
└── service/               # 服务层（@reco-m/<模块名>-service）
    ├── <模块名>.service.ts # HttpService 子类
    └── index.ts            # 桶导出 export *
```

大模块可包含多个页面子目录（如 workorder 下有 apply/、consult/、market/ 等），但 models/ 和 service/ 保持统一。(备注：如果项目中已有模块未按照标准格式创建不需要帮它调整，直接分析现有模块创建页面，以防止改动历史模块业务逻辑)

---

## 3. 命名规范

| 类型 | 规则 | 示例 |
|------|------|------|
| 目录 | 小写 + 中划线 | `mall-management-system` |
| 方法 / 变量 | 小驼峰 | `getUserInfo` |
| 组件 / 类 | 大驼峰 | `ArticleDetail` |
| 枚举 | `Bi` 开头 + `Enum` 结尾 | `BiSignTypeEnum` |
| 接口服务类 | 大驼峰 + `HttpService` | `ArticleHttpService` |
| 接口服务实例 | 小驼峰 + `HttpService` | `articleHttpService` |
| 路由方法 | 小驼峰 + `Routes` | `articleRoutes` |
| 命名空间 | `ipark-` 前缀 | `ipark-article` |

---

## 4. Namespaces（命名空间枚举）

每个模块的 `models/common.ts`：

```typescript
export enum Namespaces {
    article = "ipark-article",
    articleDetail = "ipark-articleDetail"
}
```

所有引用必须通过 `Namespaces.xxx`，禁止硬编码字符串。

---

## 5. Model 模板

```typescript
import { EffectsMapObject } from "dva";
import { ReducersMapObject, AnyAction } from "redux";
import produce, { freeze } from "immer";
import { CoreEffects, CoreReducers } from "@reco-m/core";
import { app } from "@reco-m/core-ui";
import { Namespaces } from "./common";

export namespace xxxModel {
    export const namespace = Namespaces.xxx;
    export type StateType = typeof state;
    export const state: any = freeze({}, !0);
    export const reducers: ReducersMapObject<any, AnyAction> = {
        ...CoreReducers,
        init() { return state; },
    };
    export const effects: EffectsMapObject = {
        ...CoreEffects,
        *initPage({ message }, { put }) {
            put({ type: "showLoading" });
            try { yield put({ type: "getDatas", message }); }
            catch (e) { console.log("catcherror", e?.errmsg || e); message!.error(`${e?.errmsg || e}`); }
        },
        *getDatas({ message }, { call, put }) {
            try {
                // const result = yield call(xxxHttpService.getList, params);
                // yield put({ type: "input", data: { list: result } });
            } catch (e) { console.log("catcherror", e?.errmsg || e); message!.error(`${e?.errmsg || e}`);
            } finally { yield put({ type: "hideLoading" }); }
        },
    };
}
app.model(xxxModel);
```
如果开发中提供了具体业务的接口要创建列表页面，更多列表页面Model搭建细节可以参考[列表搭建细节](references/mobilelistbuild.md),如果检索不到该文件就使用技能rg-mobile-list-build来创建，其中包含了列表页面的状态管理、分页数据更新、竞态控制等关键逻辑（注意：创建列表需要严格按照模板规范，避免手动修改模板代码，特别是 getXxxPage 方法，它是列表数据更新的核心逻辑）。

**要点**：`state` 用 `freeze({}, !0)` 冻结；`reducers` 继承 `CoreReducers`，不可变更新用 `produce`；`effects` 继承 `CoreEffects`，generator 处理异步；末尾 `app.model()` 注册；列表 model 初始 state 含 `pageIndex: 1`。

---

## 6. HttpService 模板

```typescript
import { HttpService, resolveService } from "@reco-m/core";

export class XxxHttpService extends HttpService {
    constructor() { super("api/前缀路径"); }
    /** 获取列表 */
    getList(data?: any) { return this.httpGet("", this.resolveRequestParams(data)); }
    /** 获取详情 */
    getDetail(id: string) { return this.httpGet(id); }
    /** 新增 */
    add(data: any) { return this.httpPost("", data); }
    /** 更新 */
    update(data: any) { return this.httpPut("", data); }
}
export const xxxHttpService = resolveService(XxxHttpService);
```

**要点**：继承 `HttpService`，`super("api前缀")`；GET 参数用 `this.resolveRequestParams(data)`；`resolveService()` 导出单例；一个文件可含多个 Service 类。

---

## 7. 页面组件模板

### 7.1 基础页面（ViewComponent）

```typescript
import React from "react";
import { template } from "@reco-m/core";
import { ViewComponent } from "@reco-m/core-ui";
import { Namespaces, xxxModel } from "../models";

export namespace Xxx {
    export interface IProps<S extends IState = IState> extends ViewComponent.IProps<S> {}
    export interface IState extends ViewComponent.IState, xxxModel.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ViewComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.xxx;
        headerContent = "页面标题";
        componentDidMount() { this.dispatch({ type: "initPage", data: {} }); }
        componentWillUnmount() { this.dispatch({ type: "init" }); }
        renderBody(): React.ReactNode { return <div></div>; }
    }
    export const Page = template(Component, (state) => state[Namespaces.xxx]);
}
```

### 7.2 列表页面（ListComponent）

```typescript
import React from "react";
import { template } from "@reco-m/core";
import { ListComponent, Container } from "@reco-m/core-ui";
import { Namespaces, xxxModel } from "../models";

export namespace Xxx {
    export interface IProps<S extends IState = IState> extends ListComponent.IProps<S> {}
    export interface IState extends ListComponent.IState, xxxModel.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState> extends ListComponent.Base<P, S> {
        showloading = true;
        namespace = Namespaces.xxx;
        headerContent = "列表标题";
        componentDidMount() { this.dispatch({ type: "initPage", data: {} }); }
        componentWillUnmount() { this.dispatch({ type: "init" }); }
        /** 刷新列表 */
        onRefresh() { this.getData(1); }
        /** 下拉刷新 */
        pullToRefresh() { this.getData(1); }
        /** 上拉加载更多 */
        onEndReached() { this.getData((this.props.state!.pageIndex || 0) + 1); }
        /** 获取数据 */
        getData(pageIndex?: number) { this.dispatch({ type: "getList", pageIndex }); }
        /** 渲染列表项 */
        renderItemContent(item: any, i: number): React.ReactNode { return <div key={item.id || i}></div>; }
        renderBody(): React.ReactNode {
            const { state } = this.props;
            return (state as any).refreshing !== false ? null : <Container.Component body>{this.getListView()}</Container.Component>;
        }
    }
    export const Page = template(Component, (state) => state[Namespaces.xxx]);
}
```

### 7.3 表单页面（EfficientFormViewComponent）

```typescript
import React from "react";
import { template, Validators } from "@reco-m/core";
import { Container, FooterButton } from "@reco-m/core-ui";
import { EfficientFormViewComponent } from "@reco-m/efficient-page";
import { Namespaces, xxxModel } from "../models";

export namespace XxxForm {
    export interface IProps<S extends IState = IState> extends EfficientFormViewComponent.IProps<S> {}
    export interface IState extends EfficientFormViewComponent.IState, xxxModel.StateType {}
    export class Component<P extends IProps = IProps, S extends IState = IState>
        extends EfficientFormViewComponent.Component<P, S> {
        showloading = true;
        namespace = Namespaces.xxx;
        headerContent = "表单标题";
        /** 表单校验 */
        check() {
            const { state } = this.props;
            const { required, composeControl, ValidatorControl } = Validators;
            return ValidatorControl(composeControl([required], { value: state!.name, name: "名称" }));
        }
        /** 提交表单 */
        submit() {
            const msg = this.check()!();
            if (msg) { this.message.error(msg); return; }
            this.openLoading();
            this.dispatch({ type: "saveData" })
                .then(() => { this.message.success("提交成功"); this.goBack(); })
                .catch((e) => { this.message.error(`${e?.errmsg || e}`); })
                .finally(() => { this.closeLoading(); });
        }
        renderBody(): React.ReactNode {
            return <Container.Component body>{/* renderInput / renderPick / renderTags */}</Container.Component>;
        }
        renderFooter(): React.ReactNode {
            return <FooterButton.Component onClick={() => this.submit()}>提交</FooterButton.Component>;
        }
    }
    export const Page = template(Component, (state) => state[Namespaces.xxx]);
}
```

**组件要点**：所有页面包裹在 `export namespace Xxx {}` 中；`template(Component, stateSelector)` 绑定 store；`componentDidMount` dispatch `initPage`；`componentWillUnmount` dispatch `init` 清 state；属性顺序：`showloading` → `namespace` → `headerContent` → 自定义。

---

## 8. 路由定义模板

```typescript
import React from "react";
import { router } from "dva";
import { Route } from "@reco-m/core-ui";
import { Xxx } from "./xxx";
import { XxxDetail } from "./xxx.detail";
export { Xxx, XxxDetail };

/** 模块路由 */
export function xxxRoutes(match: router.match) {
    return (
        <Route path={`${match.path}/xxx`} render={({ match }) => (
            <><Route path={match.path} component={Xxx.Page} />{xxxDetailRoutes(match)}</>
        )} />
    );
}
/** 详情路由 */
export function xxxDetailRoutes(match: router.match) {
    return (
        <Route path={`${match.path}/xxxDetail/:id`} render={({ match }) => (
            <><Route path={match.path} component={XxxDetail.Page} />{/* 嵌套子路由 */}</>
        )} />
    );
}
```

顶层路由在 `src/router.tsx` 中通过 `loadLazyModule(() => import("@reco-m/xxx"))` 懒加载。

---

## 9. 常用基类方法 & 异步规范

```typescript
this.getSearchParam("id");                          // 获取 URL 查询参数
this.dispatch({ type: "action", data: {} });         // 派发 dva action
this.dispatch({ type: "input", data: { key: val }}); // 更新 state（内置 reducer）
this.dispatch({ type: "update", data: {} });         // 合并更新 state
this.message.error/info/success/warning("...");      // Toast 提示
this.openLoading(); this.closeLoading();             // 手动控制 loading
this.renderEmbeddedView(Component.Page, props);      // 嵌入渲染子组件
this.isAuth();                                       // 判断是否已登录
this.goBack();                                       // 返回上一页
this.shouldUpdateData(nextProps.state);              // 列表数据变化检测
```

**异步必须用 Promise 链，禁止 callback/errback：**

```typescript
this.openLoading();
this.dispatch({ type: "saveData", data: {} })
    .then(() => { this.message.success("操作成功"); })
    .catch((e) => { this.message.error(`${e?.errmsg || e}`); })
    .finally(() => { this.closeLoading(); });
```

---

## 10. 表单校验 & 事件通信

**Validators**（`@reco-m/core`）：

```typescript
const { required, composeControl, ValidatorControl, max, pattern, cellphone, email } = Validators;
const msg = ValidatorControl(
    composeControl([required], { value: name, name: "名称" }),
    composeControl([required, max(100)], { value: count, name: "数量" }),
    composeControl([required, cellphone], { value: phone, name: "手机号" }),
    composeControl([required, email], { value: mail, name: "邮箱" }),
)!();
if (msg) { this.message.error(msg); return; }
```

**customEvent**（跨组件刷新，替代路由变化判断）：

```typescript
import { customEvent } from "@reco-m/core";
// componentDidMount 中注册
customEvent.on("refreshList", this.handleRefresh);
// componentWillUnmount 中注销
customEvent.off("refreshList", this.handleRefresh);
// 操作成功后触发
customEvent.emit("refreshList");
```

---

## 11. 常用组件

**嵌入子组件**：`this.renderEmbeddedView(CommentList.Page, { bindTableName, bindTableId })`

**图片上传**（`@reco-m/core-ui`）：

```typescript
<Picture.Component tableName={IParkBindTableNameEnum.xxx} customType={1} fileNumLimit={9} multiple={true} readonly={false} />
```

**附件上传**（`@reco-m/core-ui`）：

```typescript
<Attach.Component tableName="bi_xxx" readonly={false} uploadSuccess={(_file, _data, _svc) => { /* ... */ }} />
```

**侧边栏筛选**（`@reco-m/efficient-page`）：

```typescript
getDrawDatas(): datasType {
    return [
        { type: "list", title: "类型", multiple: false, property: "catalog", tagLabelKey: "name", tagValueKey: "id", data: catalogs },
        { type: "tag", title: "标签", multiple: true, property: "tagValue", data: tags },
        { type: "date", title: "日期", data: [{ placeholder: "请选择", stateKey: "dateKey", mode: "month" }] },
    ];
}
<BitechDraw.Page openSideBar={state!.open} title="筛选" searchShow={true} datas={this.getDrawDatas()}
    defaultValue={{ key: "" }} resetToInit={true}
    sureDrawerData={(data) => {}} resetDrawerData={(data) => {}} onMaskClick={() => {}} />
```

**弹出选择列表**（`@reco-m/efficient-page`）：

```typescript
this.renderEmbeddedView(EfficientList.Page, {
    title: "选择人员", isPopup: true, hideInit: true, namespace: "selectPerson",
    api: "api/path", params: {},
    popConfig: { showSearch: true, labelAttr: "name", valueAttr: "id", visible: isVisible, multiple: false,
        close: () => {}, ok: (selected) => {} },
    renderItem: (item) => <div>{item.name}</div>,
});
```

---

## 12. 样式类名速查

**颜色**：`back-primary`/`color-primary`（品牌色）、`back-red/orange/yellow/green/blue`、`back-success`/`color-success`、`back-error`/`color-error`、`reco-describe`（灰色描述文字）

**间距**：`margin-{方向}-{尺寸}` / `padding-{方向}-{尺寸}`。方向：`left/right/top/bottom/v/h`。尺寸：`xxs`(4) / `xs`(8) / 默认(12) / `sm`(16) / `lg`(24) / `xl`(32)。

**文本**：`text-center/left/right`、`size-12`~`size-50`（非必要不用）、`weight-bold`、`line-1`（单行省略）。

**布局**：`width-full`/`height-full`、`block`/`inline-block`、`none`/`all-show`、`border`/`border-top/bottom/left/right`、`border-radius`。

---

## 13. 其他规范

**枚举**：`Bi` 开头 + `Enum` 结尾，每项加多行注释，放 `models/common.ts`。

**跨命名空间调用**：`this.dispatch({ type: \`${Namespaces.otherModule}/actionName\`, data: {} })`

**Loading**：页面初始化 / 切换 Tab / 提交表单 / 侧边栏查询时需要 loading；上拉加载 / 下拉刷新不需要。

---
